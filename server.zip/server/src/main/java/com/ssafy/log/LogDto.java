package com.ssafy.log;

public class LogDto {
	private String aptCode;

	public LogDto() {
	}

	public LogDto(String aptCode) {
		super();
		this.aptCode = aptCode;
	}

	public String getAptCode() {
		return aptCode;
	}

	public void setAptCode(String aptCode) {
		this.aptCode = aptCode;
	}
	
}
